import React, { useState, useEffect } from 'react';
import { Habit } from '../types';
import { getHabitAnalysis, suggestHabits } from '../services/geminiService';
import { Sparkles, Target, ArrowRight, Plus, Loader2 } from 'lucide-react';

interface AICoachProps {
  habits: Habit[];
  onAddHabit: (habit: Omit<Habit, 'id' | 'streak' | 'completedDates' | 'createdAt'>) => void;
}

const AICoach: React.FC<AICoachProps> = ({ habits, onAddHabit }) => {
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [loadingAnalysis, setLoadingAnalysis] = useState(false);
  
  const [goal, setGoal] = useState('');
  const [suggestions, setSuggestions] = useState<{ title: string; category: string; icon: string }[]>([]);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);

  useEffect(() => {
    if (habits.length > 0 && !analysis) {
      handleAnalyze();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); 

  const handleAnalyze = async () => {
    setLoadingAnalysis(true);
    const result = await getHabitAnalysis(habits);
    setAnalysis(result);
    setLoadingAnalysis(false);
  };

  const handleGetSuggestions = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!goal.trim()) return;
    setLoadingSuggestions(true);
    const results = await suggestHabits(goal);
    setSuggestions(results);
    setLoadingSuggestions(false);
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      
      {/* Analysis Section */}
      <div className="bg-[#1D1D1D] rounded-[2rem] overflow-hidden shadow-xl border border-[#2B2B2B]">
        <div className="h-32 bg-[#FAD6DC] relative overflow-hidden flex items-center justify-center">
           {/* Placeholder for whimsical illustration */}
           <img 
             src="https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?q=80&w=2574&auto=format&fit=crop" 
             className="absolute w-full h-full object-cover opacity-50 mix-blend-multiply" 
             alt="Thinking"
           />
           <div className="relative z-10 bg-[#1D1D1D]/80 backdrop-blur-md px-6 py-3 rounded-2xl border border-white/10">
             <h3 className="text-2xl font-extrabold text-white flex items-center gap-3">
               <Sparkles className="w-6 h-6 text-[#F9E58C]" />
               AI Operations Lead
             </h3>
           </div>
        </div>
        
        <div className="p-8">
          {loadingAnalysis ? (
            <div className="flex flex-col items-center justify-center gap-4 py-8">
              <Loader2 className="w-8 h-8 text-[#5A7BEF] animate-spin" />
              <span className="text-[#CCCCCC] font-medium">Crunching the numbers...</span>
            </div>
          ) : (
            <div className="prose prose-invert max-w-none">
              <div className="bg-[#2B2B2B] p-6 rounded-2xl border-l-4 border-[#F25C54]">
                <p className="text-white leading-relaxed whitespace-pre-line font-medium">
                  {analysis || "Start tracking habits to get personalized insights!"}
                </p>
              </div>
              {habits.length > 0 && (
                <button 
                  onClick={handleAnalyze}
                  className="mt-6 text-sm bg-[#333] text-white hover:bg-[#444] transition-colors px-6 py-3 rounded-xl font-bold w-full"
                >
                  Refresh Analysis
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Suggestions Section */}
      <div className="bg-[#1D1D1D] rounded-[2rem] shadow-xl border border-[#2B2B2B] p-8">
        <div className="flex items-center gap-3 mb-6">
          <Target className="w-6 h-6 text-[#9FE6A0]" />
          <h3 className="text-xl font-bold text-white uppercase tracking-wider">Strategy Planning</h3>
        </div>

        <form onSubmit={handleGetSuggestions} className="flex gap-3 mb-8">
          <input
            type="text"
            value={goal}
            onChange={(e) => setGoal(e.target.value)}
            placeholder="Enter a new goal..."
            className="flex-1 px-6 py-4 rounded-2xl bg-[#2B2B2B] border border-[#333] text-white focus:ring-2 focus:ring-[#5A7BEF] outline-none transition-all placeholder-[#555]"
          />
          <button 
            type="submit"
            disabled={loadingSuggestions || !goal.trim()}
            className="bg-[#F7941D] hover:bg-[#d47d16] text-[#1D1D1D] px-6 rounded-2xl font-bold transition-colors flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loadingSuggestions ? <Loader2 className="w-6 h-6 animate-spin" /> : <ArrowRight className="w-6 h-6" />}
          </button>
        </form>

        {suggestions.length > 0 && (
          <div className="grid grid-cols-1 gap-4">
            {suggestions.map((suggestion, index) => (
              <div key={index} className="bg-[#2B2B2B] border border-[#333] p-5 rounded-2xl flex items-center justify-between group hover:border-[#5A7BEF] transition-all">
                <div className="flex items-center gap-4">
                  <span className="text-3xl">{suggestion.icon}</span>
                  <div>
                    <h4 className="font-bold text-white text-lg">{suggestion.title}</h4>
                    <span className="text-[10px] font-bold bg-[#333] text-[#CCCCCC] px-2 py-1 rounded-md uppercase">{suggestion.category}</span>
                  </div>
                </div>
                
                <button
                  onClick={() => {
                    onAddHabit({
                      title: suggestion.title,
                      category: suggestion.category,
                      color: 'bg-[#5A7BEF]',
                      icon: suggestion.icon
                    });
                    setGoal('');
                    setSuggestions([]);
                  }}
                  className="bg-[#5A7BEF] p-3 rounded-xl text-white hover:scale-105 transition-transform shadow-lg"
                >
                  <Plus className="w-5 h-5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AICoach;