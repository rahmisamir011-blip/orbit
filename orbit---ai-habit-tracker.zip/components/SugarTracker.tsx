import React, { useState, useMemo } from 'react';
import { BarChart, Bar, XAxis, Tooltip, ResponsiveContainer, Cell, ReferenceLine } from 'recharts';
import { Trash2, Loader2, Sparkles, Coffee, Cookie, IceCream, GlassWater } from 'lucide-react';
import { SugarLog } from '../types';
import { format, subDays } from 'date-fns';
import { getSugarAnalysis } from '../services/geminiService';

interface SugarTrackerProps {
  logs: SugarLog[];
  onAddLog: (grams: number, note?: string) => void;
  onDeleteLog: (id: string) => void;
}

const SugarTracker: React.FC<SugarTrackerProps> = ({ logs, onAddLog, onDeleteLog }) => {
  const [customAmount, setCustomAmount] = useState('');
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);

  const todayStr = format(new Date(), 'yyyy-MM-dd');
  const DAILY_LIMIT = 30; 

  const todayLogs = useMemo(() => logs.filter(l => l.date === todayStr), [logs, todayStr]);
  const todayTotal = useMemo(() => todayLogs.reduce((acc, curr) => acc + curr.grams, 0), [todayLogs]);

  const weeklyData = useMemo(() => {
    const days = [];
    for (let i = 6; i >= 0; i--) {
      const date = subDays(new Date(), i);
      const dateStr = format(date, 'yyyy-MM-dd');
      const total = logs
        .filter(l => l.date === dateStr)
        .reduce((acc, l) => acc + l.grams, 0);
      
      days.push({
        name: format(date, 'EEE'),
        grams: total,
        fullDate: dateStr
      });
    }
    return days;
  }, [logs]);

  const handleAddCustom = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(customAmount);
    if (!isNaN(amount) && amount > 0) {
      onAddLog(amount, 'Custom');
      setCustomAmount('');
    }
  };

  const handleAnalyze = async () => {
    setAnalyzing(true);
    const result = await getSugarAnalysis(logs);
    setAnalysis(result);
    setAnalyzing(false);
  };

  const quickAdds = [
    { grams: 5, icon: <Coffee className="w-5 h-5" />, label: 'Coffee' },
    { grams: 10, icon: <Cookie className="w-5 h-5" />, label: 'Cookie' },
    { grams: 25, icon: <IceCream className="w-5 h-5" />, label: 'Treat' },
    { grams: 35, icon: <GlassWater className="w-5 h-5" />, label: 'Soda' },
  ];

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      {/* Header Card */}
      <div className="bg-[#F25C54] rounded-[2rem] p-8 text-[#1D1D1D] shadow-xl relative overflow-hidden">
        <div className="relative z-10">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="font-bold text-lg mb-1 opacity-80 uppercase tracking-wider">Daily Intake</h2>
              <div className="flex items-baseline gap-2">
                <span className="text-6xl font-extrabold">{todayTotal}</span>
                <span className="text-2xl font-bold opacity-60">/ {DAILY_LIMIT}g</span>
              </div>
            </div>
            <div className="bg-white/20 p-4 rounded-2xl backdrop-blur-md">
              <Cookie className="w-8 h-8 text-[#1D1D1D]" />
            </div>
          </div>
          
          {/* Progress Bar */}
          <div className="mt-8">
            <div className="h-4 bg-black/10 rounded-full overflow-hidden backdrop-blur-sm">
              <div 
                className={`h-full transition-all duration-1000 ease-out ${todayTotal > DAILY_LIMIT ? 'bg-[#1D1D1D]' : 'bg-white'}`}
                style={{ width: `${Math.min((todayTotal / DAILY_LIMIT) * 100, 100)}%` }}
              />
            </div>
            <p className="text-sm font-bold mt-2 text-right opacity-70">
              {todayTotal > DAILY_LIMIT ? '⚠️ Limit Exceeded' : `${DAILY_LIMIT - todayTotal}g Remaining`}
            </p>
          </div>
        </div>
      </div>

      {/* Quick Add */}
      <div className="bg-[#1D1D1D] p-8 rounded-[2rem] shadow-lg border border-[#2B2B2B]">
        <h3 className="font-bold text-white mb-6 uppercase tracking-wide">Quick Add</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {quickAdds.map((item, idx) => (
            <button
              key={idx}
              onClick={() => onAddLog(item.grams, item.label)}
              className="flex flex-col items-center justify-center gap-3 p-4 rounded-2xl bg-[#2B2B2B] text-white hover:bg-[#FAD6DC] hover:text-[#1D1D1D] transition-colors border border-[#333] group"
            >
              <div className="group-hover:scale-110 transition-transform">
                {item.icon}
              </div>
              <div className="text-center leading-tight">
                <span className="block text-sm font-bold">{item.label}</span>
                <span className="text-[10px] opacity-60">+{item.grams}g</span>
              </div>
            </button>
          ))}
        </div>

        <form onSubmit={handleAddCustom} className="mt-6 flex gap-3">
          <div className="relative flex-1">
            <input
              type="number"
              value={customAmount}
              onChange={(e) => setCustomAmount(e.target.value)}
              placeholder="Custom amount..."
              className="w-full pl-6 pr-12 py-4 rounded-2xl bg-[#2B2B2B] border border-[#333] text-white focus:ring-2 focus:ring-[#F25C54] outline-none"
            />
            <span className="absolute right-6 top-1/2 -translate-y-1/2 text-[#666] text-sm font-bold">g</span>
          </div>
          <button 
            type="submit"
            disabled={!customAmount}
            className="bg-[#F25C54] text-[#1D1D1D] px-8 rounded-2xl font-bold disabled:opacity-50 hover:bg-[#d64b43] transition-colors"
          >
            Add
          </button>
        </form>
      </div>

      {/* Today's Logs & Analysis */}
      <div className="grid grid-cols-1 gap-6">
        {/* History */}
        <div className="bg-[#1D1D1D] p-8 rounded-[2rem] shadow-lg border border-[#2B2B2B]">
           <div className="flex items-center justify-between mb-6">
             <h3 className="font-bold text-white uppercase tracking-wide">Log History</h3>
             <span className="text-xs font-bold text-[#9FE6A0] bg-[#2B2B2B] px-3 py-1 rounded-full">Today</span>
           </div>
          
          {todayLogs.length === 0 ? (
            <p className="text-[#666] text-center py-4">No sugar tracked today.</p>
          ) : (
            <div className="space-y-3">
              {todayLogs.map(log => (
                <div key={log.id} className="flex items-center justify-between p-4 rounded-2xl bg-[#2B2B2B]">
                  <div className="flex items-center gap-3">
                    <span className="w-3 h-3 rounded-full bg-[#F25C54]"></span>
                    <span className="text-white font-medium">{log.note || 'Entry'}</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="font-bold text-[#CCCCCC]">{log.grams}g</span>
                    <button 
                      onClick={() => onDeleteLog(log.id)}
                      className="text-[#666] hover:text-[#F25C54]"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* AI Analysis */}
        <div className="bg-[#F9E58C] text-[#1D1D1D] p-8 rounded-[2rem] shadow-xl">
          <div className="flex items-center gap-3 mb-4">
            <Sparkles className="w-6 h-6 text-[#1D1D1D]" />
            <h3 className="font-bold text-xl">Dietary Insights</h3>
          </div>
          
          {analyzing ? (
             <div className="flex items-center py-4 gap-3 font-medium">
               <Loader2 className="w-5 h-5 animate-spin" />
               <span>Analyzing data...</span>
             </div>
          ) : analysis ? (
            <div className="prose prose-p:text-[#1D1D1D] prose-p:font-medium">
              <p>{analysis}</p>
              <button 
                onClick={handleAnalyze}
                className="mt-4 text-xs bg-black/10 hover:bg-black/20 px-4 py-2 rounded-full transition-colors font-bold uppercase"
              >
                Update Analysis
              </button>
            </div>
          ) : (
            <div className="py-2">
              <p className="text-[#1D1D1D]/80 font-medium mb-6">Get an AI-powered breakdown of your sugar consumption patterns.</p>
              <button 
                onClick={handleAnalyze}
                disabled={logs.length === 0}
                className="bg-[#1D1D1D] text-white px-6 py-3 rounded-xl font-bold hover:scale-105 transition-transform disabled:opacity-50"
              >
                Generate Report
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SugarTracker;