import React, { useMemo } from 'react';
import { Habit } from '../types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';
import { format, subDays } from 'date-fns';

interface StatsViewProps {
  habits: Habit[];
}

const StatsView: React.FC<StatsViewProps> = ({ habits }) => {
  
  // Calculate completion rate for the last 7 days
  const weeklyData = useMemo(() => {
    const days = [];
    for (let i = 6; i >= 0; i--) {
      const date = subDays(new Date(), i);
      const dateStr = format(date, 'yyyy-MM-dd');
      
      let completedCount = 0;
      habits.forEach(habit => {
        if (habit.completedDates.includes(dateStr)) {
          completedCount++;
        }
      });

      days.push({
        name: format(date, 'EEE'), // Mon, Tue, etc.
        completed: completedCount,
        total: habits.length
      });
    }
    return days;
  }, [habits]);

  // Calculate category distribution
  const categoryData = useMemo(() => {
    const counts: Record<string, number> = {};
    habits.forEach(h => {
      counts[h.category] = (counts[h.category] || 0) + 1;
    });
    return Object.keys(counts).map(key => ({
      name: key,
      value: counts[key]
    }));
  }, [habits]);

  // Palette colors for charts
  const CHART_COLORS = ['#F9E58C', '#F25C54', '#5A7BEF', '#F7941D', '#FAD6DC', '#9FE6A0'];

  if (habits.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-[#CCCCCC]">
        <p>No data available.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="bg-[#1D1D1D] p-6 rounded-[2rem] shadow-lg border border-[#2B2B2B]">
        <h3 className="text-xl font-bold text-white mb-6 uppercase tracking-wide">Weekly Performance</h3>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={weeklyData}>
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#666', fontSize: 12, fontWeight: 'bold'}} dy={10} />
              <YAxis hide />
              <Tooltip 
                cursor={{fill: '#2B2B2B'}}
                contentStyle={{backgroundColor: '#1D1D1D', borderRadius: '16px', border: '1px solid #333', color: '#fff'}}
              />
              <Bar dataKey="completed" fill="#5A7BEF" radius={[8, 8, 8, 8]} barSize={24}>
                {weeklyData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.completed >= entry.total && entry.total > 0 ? '#9FE6A0' : '#5A7BEF'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-[#1D1D1D] p-6 rounded-[2rem] shadow-lg border border-[#2B2B2B]">
          <h3 className="text-lg font-bold text-white mb-4 uppercase tracking-wide">Categories</h3>
          <div className="h-56 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={70}
                  paddingAngle={5}
                  dataKey="value"
                  stroke="none"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{backgroundColor: '#1D1D1D', borderRadius: '12px', border: 'none'}} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap justify-center gap-2 mt-4">
            {categoryData.map((entry, index) => (
              <div key={entry.name} className="flex items-center text-[10px] font-bold text-[#CCCCCC] bg-[#2B2B2B] px-2 py-1 rounded-lg">
                <span className="w-2 h-2 rounded-full mr-2" style={{ backgroundColor: CHART_COLORS[index % CHART_COLORS.length] }}></span>
                {entry.name}
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#1D1D1D] p-6 rounded-[2rem] shadow-lg border border-[#2B2B2B]">
          <h3 className="text-lg font-bold text-white mb-6 uppercase tracking-wide">Top Streaks</h3>
          <div className="space-y-4">
            {[...habits].sort((a, b) => b.streak - a.streak).slice(0, 5).map((habit, idx) => (
              <div key={habit.id} className="flex items-center justify-between border-b border-[#2B2B2B] pb-3 last:border-0">
                <div className="flex items-center gap-3">
                  <span className="text-xl">{habit.icon}</span>
                  <span className="font-bold text-white">{habit.title}</span>
                </div>
                <div className="flex items-center gap-1 text-[#F7941D] font-extrabold">
                  <span>{habit.streak}</span>
                  <span className="text-xs text-[#666]">days</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatsView;