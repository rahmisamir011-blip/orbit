import React, { useState, useEffect } from 'react';
import { Moon, Sun, Sunrise, Sunset, Cloud, MapPin, Loader2, Clock, Bell } from 'lucide-react';
import { format } from 'date-fns';

interface PrayerTimesProps {
  timings: Record<string, string> | null;
  hijriDate: string | null;
  locationName: string | null;
  loading: boolean;
  error: string | null;
}

const PrayerTimes: React.FC<PrayerTimesProps> = ({ timings, hijriDate, locationName, loading, error }) => {
  const [nextPrayer, setNextPrayer] = useState<string | null>(null);
  const [timeLeft, setTimeLeft] = useState<string>('');

  const PRAYER_NAMES = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
  
  const getIcon = (name: string) => {
    switch (name) {
      case 'Fajr': return <Moon className="w-5 h-5" />;
      case 'Sunrise': return <Sunrise className="w-5 h-5" />;
      case 'Dhuhr': return <Sun className="w-5 h-5" />;
      case 'Asr': return <Cloud className="w-5 h-5" />;
      case 'Maghrib': return <Sunset className="w-5 h-5" />;
      case 'Isha': return <Moon className="w-5 h-5" />;
      default: return <Clock className="w-5 h-5" />;
    }
  };

  useEffect(() => {
    if (!timings) return;

    const interval = setInterval(() => {
      calculateNextPrayer();
    }, 1000);
    calculateNextPrayer();

    return () => clearInterval(interval);
  }, [timings]);

  const calculateNextPrayer = () => {
    if (!timings) return;
    
    const now = new Date();
    const timeStr = format(now, 'HH:mm');
    let foundNext = false;

    for (const name of PRAYER_NAMES) {
      if (timings[name] > timeStr) {
        setNextPrayer(name);
        
        const [pH, pM] = timings[name].split(':').map(Number);
        const prayerDate = new Date();
        prayerDate.setHours(pH, pM, 0);
        
        const diff = prayerDate.getTime() - now.getTime();
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diff % (1000 * 60)) / 1000);
        
        setTimeLeft(`${hours}h ${minutes}m ${seconds}s`);
        foundNext = true;
        break;
      }
    }

    if (!foundNext) {
      setNextPrayer('Fajr');
      setTimeLeft('Tomorrow');
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-[#CCCCCC]">
        <Loader2 className="w-8 h-8 animate-spin mb-2 text-[#5A7BEF]" />
        <p>Locating...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-[#F25C54] p-6 text-center">
        <MapPin className="w-10 h-10 mb-3 opacity-50" />
        <p className="font-bold">{error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      
      {/* Hero Section */}
      <div className="bg-[#5A7BEF] rounded-[2.5rem] p-8 text-white shadow-xl relative overflow-hidden">
        {/* Abstract Circles */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full blur-3xl -translate-y-1/3 translate-x-1/3"></div>
        <div className="absolute bottom-0 left-0 w-40 h-40 bg-[#1D1D1D]/10 rounded-full blur-3xl translate-y-1/3 -translate-x-1/3"></div>

        <div className="relative z-10">
          <div className="flex items-start justify-between mb-8">
             <div>
               <p className="text-blue-100 text-sm font-bold mb-2 uppercase tracking-wider">Upcoming Prayer</p>
               <h2 className="text-5xl font-extrabold text-white mb-2">{nextPrayer}</h2>
               <div className="flex items-center gap-2 text-white bg-white/20 px-4 py-1.5 rounded-full w-fit backdrop-blur-md border border-white/10">
                 <Clock className="w-4 h-4" />
                 <span className="text-sm font-mono font-bold">{timeLeft}</span>
               </div>
             </div>
             <div className="bg-white/20 backdrop-blur-md p-4 rounded-2xl border border-white/10">
               <Moon className="w-8 h-8 text-[#F9E58C]" />
             </div>
          </div>

          <div className="flex items-center justify-between text-xs font-bold text-blue-100 pt-6 border-t border-white/10">
             <div className="flex items-center gap-2">
               <MapPin className="w-4 h-4" />
               <span>{locationName || 'Unknown Location'}</span>
             </div>
             <span>{hijriDate}</span>
          </div>
        </div>
      </div>

      {/* Notification Tip */}
      <div className="bg-[#F9E58C] rounded-2xl p-4 flex items-center gap-4 text-[#1D1D1D] shadow-sm">
         <div className="bg-[#1D1D1D] p-2 rounded-full text-[#F9E58C]">
            <Bell className="w-4 h-4" />
         </div>
         <p className="text-sm font-bold leading-tight">Alerts enabled for 5 minutes prior to prayer.</p>
      </div>

      {/* Timings List */}
      <div className="bg-[#1D1D1D] rounded-[2rem] shadow-xl border border-[#2B2B2B] overflow-hidden p-4">
         {timings && Object.entries(timings).filter(([name]) => PRAYER_NAMES.includes(name) || name === 'Sunrise').map(([name, timeValue]) => {
           const time = timeValue as string;
           const isNext = name === nextPrayer;
           return (
             <div 
               key={name}
               className={`flex items-center justify-between p-5 rounded-2xl mb-2 last:mb-0 transition-all ${isNext ? 'bg-[#5A7BEF] text-white shadow-lg transform scale-[1.02]' : 'text-[#CCCCCC] hover:bg-[#2B2B2B]'}`}
             >
               <div className="flex items-center gap-4">
                 <div className={`${isNext ? 'text-white' : 'text-[#555]'}`}>
                    {getIcon(name)}
                 </div>
                 <span className="font-bold text-lg">{name}</span>
               </div>
               <span className={`text-xl font-bold ${isNext ? 'text-white' : 'text-[#F9E58C]'}`}>
                 {parseInt(time.split(':')[0]) > 12 
                   ? `${parseInt(time.split(':')[0]) - 12}:${time.split(':')[1]}` 
                   : time}
                 <span className="text-xs ml-1 opacity-60">{parseInt(time.split(':')[0]) >= 12 ? 'PM' : 'AM'}</span>
               </span>
             </div>
           );
         })}
      </div>
    </div>
  );
};

export default PrayerTimes;