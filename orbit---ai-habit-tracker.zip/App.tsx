import React, { useState, useEffect, useRef } from 'react';
import { Plus, LayoutDashboard, LineChart, Sparkles, X, Check, Trash2, Trophy, Cookie, Clock, Bell, Moon } from 'lucide-react';
import { format, subDays } from 'date-fns';
import { Habit, ViewMode, CATEGORIES, COLORS, EMOJIS, SugarLog } from './types';
import StatsView from './components/StatsView';
import AICoach from './components/AICoach';
import SugarTracker from './components/SugarTracker';
import { getMotivationalQuote } from './services/geminiService';

const App: React.FC = () => {
  // --- State ---
  const [habits, setHabits] = useState<Habit[]>(() => {
    const saved = localStorage.getItem('orbit-habits');
    return saved ? JSON.parse(saved) : [];
  });

  const [sugarLogs, setSugarLogs] = useState<SugarLog[]>(() => {
    const saved = localStorage.getItem('orbit-sugar-logs');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [view, setView] = useState<ViewMode>('dashboard');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [motivationalQuote, setMotivationalQuote] = useState<string | null>(null);
  const [quoteLoading, setQuoteLoading] = useState(false);
  
  // Prayer State
  const [prayerTimings, setPrayerTimings] = useState<Record<string, string> | null>(null);
  const [nextPrayer, setNextPrayer] = useState<{name: string, time: string, countdown: string} | null>(null);

  // Form State
  const [newHabitTitle, setNewHabitTitle] = useState('');
  const [newHabitCategory, setNewHabitCategory] = useState(CATEGORIES[0]);
  const [newHabitColor, setNewHabitColor] = useState(COLORS[0]);
  const [newHabitIcon, setNewHabitIcon] = useState(EMOJIS[0]);
  const [newHabitTime, setNewHabitTime] = useState('');

  // Refs
  const lastCheckedMinute = useRef<string>('');
  const lastPrayerNotification = useRef<string>('');

  // --- Effects ---
  useEffect(() => {
    localStorage.setItem('orbit-habits', JSON.stringify(habits));
  }, [habits]);

  useEffect(() => {
    localStorage.setItem('orbit-sugar-logs', JSON.stringify(sugarLogs));
  }, [sugarLogs]);

  // Notification Permissions & Prayer Data Fetch (Birtouta Fixed)
  useEffect(() => {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }
    
    // Fetch Prayer Times for Birtouta (Lat: 36.6639, Long: 3.0038)
    const fetchPrayerTimes = async () => {
      try {
        const latitude = 36.6639;
        const longitude = 3.0038;
        const timestamp = Math.floor(Date.now() / 1000);
        const response = await fetch(`https://api.aladhan.com/v1/timings/${timestamp}?latitude=${latitude}&longitude=${longitude}&method=2`);
        const data = await response.json();
        
        if (data.code === 200) {
          setPrayerTimings(data.data.timings);
        }
      } catch (err) {
        console.error('Failed to fetch prayer times', err);
      }
    };

    fetchPrayerTimes();
  }, []);

  // Update Next Prayer UI
  useEffect(() => {
    if (!prayerTimings) return;

    const updatePrayerStatus = () => {
       const now = new Date();
       const timeStr = format(now, 'HH:mm');
       const PRAYER_NAMES = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
       
       let found = false;
       for (const name of PRAYER_NAMES) {
         if (prayerTimings[name] > timeStr) {
           const [ph, pm] = prayerTimings[name].split(':').map(Number);
           const pDate = new Date();
           pDate.setHours(ph, pm, 0);
           
           const diff = pDate.getTime() - now.getTime();
           const hours = Math.floor(diff / (1000 * 60 * 60));
           const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
           
           setNextPrayer({
             name,
             time: prayerTimings[name],
             countdown: `${hours}h ${minutes}m`
           });
           found = true;
           break;
         }
       }
       
       if (!found) {
          setNextPrayer({ name: 'Fajr', time: prayerTimings['Fajr'], countdown: 'Tomorrow' });
       }
    };

    const interval = setInterval(updatePrayerStatus, 1000);
    updatePrayerStatus();
    return () => clearInterval(interval);
  }, [prayerTimings]);

  // Check Reminders
  useEffect(() => {
    const checkReminders = () => {
      const now = new Date();
      const timeString = format(now, 'HH:mm');
      const todayStr = format(now, 'yyyy-MM-dd');

      if (timeString === lastCheckedMinute.current) return;
      lastCheckedMinute.current = timeString;

      // 1. Habit Reminders
      habits.forEach(habit => {
        if (habit.reminderTime === timeString) {
          if (!habit.completedDates.includes(todayStr)) {
            sendNotification(`Time for ${habit.title}!`, `Keep your streak of ${habit.streak} going! ${habit.icon}`);
          }
        }
      });

      // 2. Prayer Reminders (Exact Time)
      if (prayerTimings) {
        const PRAYER_NAMES = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
        PRAYER_NAMES.forEach(name => {
          const prayerTimeStr = prayerTimings[name]; // HH:mm
          const prayerKey = `${todayStr}-${name}`;

          if (timeString === prayerTimeStr && lastPrayerNotification.current !== prayerKey) {
            sendNotification(`It's time for ${name} 🕌`, `Time to pray ${name}.`);
            lastPrayerNotification.current = prayerKey;
          }
        });
      }
    };

    const intervalId = setInterval(checkReminders, 2000);
    return () => clearInterval(intervalId);
  }, [habits, prayerTimings]);

  // --- Helpers ---
  const sendNotification = (title: string, body: string) => {
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(title, {
        body,
        icon: 'https://cdn-icons-png.flaticon.com/512/2693/2693507.png',
        requireInteraction: false,
        silent: false
      });
    }
  };

  // --- Handlers ---
  const addHabit = (habitData: Omit<Habit, 'id' | 'streak' | 'completedDates' | 'createdAt'>) => {
    const newHabit: Habit = {
      id: crypto.randomUUID(),
      ...habitData,
      streak: 0,
      completedDates: [],
      createdAt: new Date().toISOString(),
    };
    setHabits(prev => [...prev, newHabit]);
    setIsModalOpen(false);
    resetForm();
  };

  const handleCreateHabit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHabitTitle.trim()) return;
    
    addHabit({
      title: newHabitTitle,
      category: newHabitCategory,
      color: newHabitColor,
      icon: newHabitIcon,
      reminderTime: newHabitTime || undefined
    });
  };

  const resetForm = () => {
    setNewHabitTitle('');
    setNewHabitCategory(CATEGORIES[0]);
    setNewHabitColor(COLORS[0]);
    setNewHabitIcon(EMOJIS[0]);
    setNewHabitTime('');
  };

  const toggleHabitCompletion = async (id: string) => {
    const today = format(new Date(), 'yyyy-MM-dd');
    
    setHabits(prev => prev.map(habit => {
      if (habit.id !== id) return habit;

      const isCompletedToday = habit.completedDates.includes(today);
      let newDates = isCompletedToday
        ? habit.completedDates.filter(d => d !== today)
        : [...habit.completedDates, today];
      
      // Simple streak recalc for visual feedback
      let tempStreak = 0;
      let d = new Date();
      if (!newDates.includes(format(d, 'yyyy-MM-dd'))) {
        d = subDays(d, 1);
      }
      while (true) {
        if (newDates.includes(format(d, 'yyyy-MM-dd'))) {
          tempStreak++;
          d = subDays(d, 1);
        } else {
          break;
        }
      }
      
      return { ...habit, completedDates: newDates, streak: tempStreak };
    }));

    const habit = habits.find(h => h.id === id);
    if (habit && !habit.completedDates.includes(today)) {
      setQuoteLoading(true);
      const quote = await getMotivationalQuote(habit.title);
      setMotivationalQuote(quote);
      setQuoteLoading(false);
      setTimeout(() => setMotivationalQuote(null), 5000);
    }
  };

  const deleteHabit = (id: string) => {
    if (confirm('Are you sure you want to delete this habit?')) {
      setHabits(prev => prev.filter(h => h.id !== id));
    }
  };

  // Sugar Handlers
  const addSugarLog = (grams: number, note?: string) => {
    const newLog: SugarLog = {
      id: crypto.randomUUID(),
      grams,
      date: format(new Date(), 'yyyy-MM-dd'),
      timestamp: new Date().toISOString(),
      note
    };
    setSugarLogs(prev => [...prev, newLog]);
  };

  const deleteSugarLog = (id: string) => {
    setSugarLogs(prev => prev.filter(l => l.id !== id));
  };

  const getCompletionStatus = (habit: Habit, dateOffset: number) => {
    const dateStr = format(subDays(new Date(), dateOffset), 'yyyy-MM-dd');
    return habit.completedDates.includes(dateStr);
  };

  return (
    <div className="min-h-screen pb-24 font-sans">
      
      <div className="max-w-md mx-auto pt-6 px-4">
        {/* Header */}
        <header className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="bg-[#1D1D1D] text-white p-3 rounded-2xl shadow-lg">
              <Trophy className="w-6 h-6 text-[#F9E58C]" />
            </div>
            <div>
               <h1 className="text-2xl font-extrabold text-[#1D1D1D] tracking-tight">ORBIT</h1>
               <p className="text-xs font-semibold text-[#5A7BEF] uppercase tracking-wider">Dashboard</p>
            </div>
          </div>
          <button 
            onClick={() => setIsModalOpen(true)}
            className="bg-[#1D1D1D] text-white w-12 h-12 rounded-full flex items-center justify-center shadow-xl active:scale-95 transition-transform"
          >
            <Plus className="w-6 h-6" />
          </button>
        </header>

        {/* Motivational Toast */}
        {motivationalQuote && (
          <div className="fixed top-6 left-1/2 transform -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-4 duration-500 w-[90%] max-w-md">
            <div className="bg-[#1D1D1D] text-white px-6 py-4 rounded-3xl shadow-2xl flex items-center gap-4 border border-[#2B2B2B]">
              <Sparkles className="w-6 h-6 text-[#F9E58C] flex-shrink-0" />
              <p className="text-sm font-bold leading-relaxed">{motivationalQuote}</p>
            </div>
          </div>
        )}

        <main className="space-y-6">
          {view === 'dashboard' && (
            <div className="space-y-4 animate-in fade-in duration-500">
              {/* Prayer Bar Widget */}
              {nextPrayer && (
                <div className="bg-[#1D1D1D] rounded-[2rem] p-5 border border-[#2B2B2B] shadow-lg flex items-center justify-between relative overflow-hidden">
                  <div className="relative z-10 flex items-center gap-4">
                     <div className="bg-[#5A7BEF] p-3 rounded-xl text-white">
                        <Moon className="w-5 h-5" />
                     </div>
                     <div>
                        <p className="text-[#CCCCCC] text-[10px] font-bold uppercase tracking-wider mb-0.5">Next Prayer</p>
                        <h3 className="text-white font-bold text-xl leading-none">{nextPrayer.name}</h3>
                     </div>
                  </div>
                  <div className="relative z-10 text-right">
                     <p className="text-[#5A7BEF] font-bold font-mono text-xl">{nextPrayer.time}</p>
                     <p className="text-[#666] text-xs font-medium">{nextPrayer.countdown}</p>
                  </div>
                  {/* Decorative gradient */}
                  <div className="absolute right-0 top-0 bottom-0 w-20 bg-gradient-to-l from-[#5A7BEF]/10 to-transparent"></div>
                </div>
              )}

              {habits.length === 0 ? (
                <div className="bg-[#1D1D1D] rounded-[2rem] p-8 text-center shadow-xl border border-[#2B2B2B]">
                  <img 
                    src="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564&auto=format&fit=crop" 
                    alt="Abstract" 
                    className="w-32 h-32 object-cover rounded-full mx-auto mb-6 opacity-80 ring-4 ring-[#2B2B2B]"
                  />
                  <h2 className="text-2xl font-bold text-white mb-2">No Habits Yet</h2>
                  <p className="text-[#CCCCCC] mb-6">Start building your routine today.</p>
                  <button 
                    onClick={() => setIsModalOpen(true)}
                    className="bg-[#F7941D] text-[#1D1D1D] px-8 py-4 rounded-2xl font-bold w-full transition-transform hover:scale-[1.02]"
                  >
                    Create Your First Habit
                  </button>
                </div>
              ) : (
                <div className="grid gap-4">
                  {habits.map(habit => {
                    const isCompletedToday = habit.completedDates.includes(format(new Date(), 'yyyy-MM-dd'));
                    return (
                      <div 
                        key={habit.id} 
                        className="relative group bg-[#1D1D1D] p-6 rounded-[2rem] border border-[#2B2B2B] shadow-lg transition-all hover:-translate-y-1"
                      >
                        <div className="flex justify-between items-start mb-4">
                           <div className="flex items-center gap-4">
                             <div className="text-3xl bg-[#2B2B2B] w-14 h-14 flex items-center justify-center rounded-2xl">
                               {habit.icon}
                             </div>
                             <div>
                               <h3 className="text-white font-bold text-lg leading-tight">{habit.title}</h3>
                               <div className="flex items-center gap-2 mt-1">
                                 <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md text-[#1D1D1D] ${habit.color}`}>
                                   {habit.category.toUpperCase()}
                                 </span>
                                 {habit.reminderTime && (
                                  <span className="flex items-center gap-1 text-[#CCCCCC] text-xs">
                                    <Bell className="w-3 h-3" />
                                    {habit.reminderTime}
                                  </span>
                                 )}
                               </div>
                             </div>
                           </div>
                           <button
                            onClick={() => deleteHabit(habit.id)}
                            className="text-[#2B2B2B] hover:text-[#F25C54] transition-colors"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>

                        <div className="flex items-end justify-between">
                          <div className="flex-1">
                            <p className="text-[#CCCCCC] text-xs font-medium uppercase tracking-wider mb-1">Current Streak</p>
                            <div className="flex items-baseline gap-1">
                              <span className="text-4xl font-extrabold text-white">{habit.streak}</span>
                              <span className="text-sm text-[#CCCCCC] font-medium">days</span>
                            </div>
                          </div>

                          <button
                            onClick={() => toggleHabitCompletion(habit.id)}
                            className={`w-16 h-16 rounded-2xl flex items-center justify-center transition-all duration-300 shadow-inner ${
                              isCompletedToday 
                                ? 'bg-[#9FE6A0] text-[#1D1D1D]' 
                                : 'bg-[#2B2B2B] text-[#555] hover:bg-[#333]'
                            }`}
                          >
                            <Check className="w-8 h-8" strokeWidth={4} />
                          </button>
                        </div>
                        
                        {/* Mini Viz */}
                        <div className="mt-6 flex gap-1.5 justify-between">
                           {[6,5,4,3,2,1,0].map(d => {
                             const done = getCompletionStatus(habit, d);
                             return (
                               <div key={d} className={`h-1.5 flex-1 rounded-full ${done ? 'bg-[#F7941D]' : 'bg-[#333]'}`} />
                             )
                           })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {view === 'analytics' && <StatsView habits={habits} />}
          {view === 'coach' && <AICoach habits={habits} onAddHabit={addHabit} />}
          {view === 'sugar' && <SugarTracker logs={sugarLogs} onAddLog={addSugarLog} onDeleteLog={deleteSugarLog} />}
        </main>

        {/* Bottom Navigation */}
        <nav className="fixed bottom-6 left-1/2 -translate-x-1/2 w-[80%] max-w-md bg-[#1D1D1D] rounded-full shadow-2xl border border-[#2B2B2B] px-2 py-2 z-40">
          <div className="flex items-center justify-between px-4">
            <NavButton active={view === 'dashboard'} onClick={() => setView('dashboard')} icon={<LayoutDashboard className="w-5 h-5" />} label="" />
            <NavButton active={view === 'analytics'} onClick={() => setView('analytics')} icon={<LineChart className="w-5 h-5" />} label="" />
            <div className="w-px h-8 bg-[#333]"></div>
            <NavButton active={view === 'coach'} onClick={() => setView('coach')} icon={<Sparkles className="w-5 h-5" />} label="" />
            <div className="w-px h-8 bg-[#333]"></div>
            <NavButton active={view === 'sugar'} onClick={() => setView('sugar')} icon={<Cookie className="w-5 h-5" />} label="" />
          </div>
        </nav>

        {/* New Habit Modal */}
        {isModalOpen && (
          <div className="fixed inset-0 bg-[#C6D1C0]/90 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center sm:p-4">
            <div className="bg-[#1D1D1D] rounded-t-[2.5rem] sm:rounded-[2.5rem] w-full max-w-md shadow-2xl overflow-hidden animate-in slide-in-from-bottom duration-300 border border-[#2B2B2B]">
              <div className="px-8 py-6 flex items-center justify-between">
                <h2 className="text-2xl font-bold text-white">New Habit</h2>
                <button onClick={() => setIsModalOpen(false)} className="bg-[#2B2B2B] text-white p-2 rounded-full hover:bg-[#333]">
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <form onSubmit={handleCreateHabit} className="p-8 space-y-6">
                <div className="space-y-3">
                  <label className="text-sm font-bold text-[#CCCCCC] uppercase tracking-wider">Habit Name</label>
                  <input
                    type="text"
                    value={newHabitTitle}
                    onChange={(e) => setNewHabitTitle(e.target.value)}
                    placeholder="Read 20 minutes..."
                    className="w-full px-6 py-4 rounded-2xl bg-[#2B2B2B] border border-[#333] text-white focus:ring-2 focus:ring-[#5A7BEF] focus:border-transparent outline-none transition-all placeholder-[#555] text-lg"
                    autoFocus
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                   <div className="space-y-3">
                    <label className="text-sm font-bold text-[#CCCCCC] uppercase tracking-wider">Category</label>
                    <div className="relative">
                      <select
                        value={newHabitCategory}
                        onChange={(e) => setNewHabitCategory(e.target.value)}
                        className="w-full px-4 py-4 rounded-2xl bg-[#2B2B2B] border border-[#333] text-white outline-none appearance-none"
                      >
                        {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <label className="text-sm font-bold text-[#CCCCCC] uppercase tracking-wider">Icon</label>
                    <select
                      value={newHabitIcon}
                      onChange={(e) => setNewHabitIcon(e.target.value)}
                      className="w-full px-4 py-4 rounded-2xl bg-[#2B2B2B] border border-[#333] text-white outline-none text-xl text-center"
                    >
                      {EMOJIS.map(e => <option key={e} value={e}>{e}</option>)}
                    </select>
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-sm font-bold text-[#CCCCCC] uppercase tracking-wider flex items-center gap-2">
                    Daily Reminder
                  </label>
                  <div className="flex items-center bg-[#2B2B2B] rounded-2xl px-4 border border-[#333]">
                    <Clock className="w-5 h-5 text-[#CCCCCC]" />
                    <input
                      type="time"
                      value={newHabitTime}
                      onChange={(e) => setNewHabitTime(e.target.value)}
                      className="w-full px-4 py-4 bg-transparent text-white outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-sm font-bold text-[#CCCCCC] uppercase tracking-wider">Badge Color</label>
                  <div className="flex flex-wrap gap-3">
                    {COLORS.map(c => (
                      <button
                        key={c}
                        type="button"
                        onClick={() => setNewHabitColor(c)}
                        className={`w-10 h-10 rounded-full transition-transform border-2 ${c} ${newHabitColor === c ? 'border-white scale-110' : 'border-transparent hover:scale-105'}`}
                      />
                    ))}
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={!newHabitTitle.trim()}
                  className="w-full bg-[#5A7BEF] hover:bg-[#4a6bdf] text-white py-5 rounded-2xl font-bold text-lg transition-all shadow-lg shadow-blue-900/20 disabled:opacity-50 disabled:cursor-not-allowed mt-6"
                >
                  Add to Dashboard
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const NavButton: React.FC<{ active: boolean; onClick: () => void; icon: React.ReactNode; label: string }> = ({ active, onClick, icon }) => (
  <button
    onClick={onClick}
    className={`w-12 h-12 flex items-center justify-center rounded-full transition-all duration-300 ${active ? 'bg-[#F9E58C] text-[#1D1D1D] scale-110' : 'text-[#CCCCCC] hover:bg-[#333]'}`}
  >
    {icon}
  </button>
);

export default App;