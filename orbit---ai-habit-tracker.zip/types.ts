export interface Habit {
  id: string;
  title: string;
  category: string; // e.g., Health, Productivity, Mindfulness
  streak: number;
  completedDates: string[]; // ISO Date strings (YYYY-MM-DD)
  color: string;
  icon: string; // Emoji
  createdAt: string;
  reminderTime?: string; // HH:mm format
}

export interface DailyLog {
  date: string;
  completedHabitIds: string[];
}

export interface SugarLog {
  id: string;
  grams: number;
  date: string; // YYYY-MM-DD
  timestamp: string; // ISO
  note?: string;
}

export type ViewMode = 'dashboard' | 'analytics' | 'coach' | 'sugar';

export const CATEGORIES = ['Health', 'Productivity', 'Learning', 'Mindfulness', 'Fitness', 'Finance', 'Other'];

// Updated Palette based on design requirements
export const COLORS = [
  'bg-[#F9E58C]', // Pale Yellow
  'bg-[#F25C54]', // Soft Red / Coral
  'bg-[#5A7BEF]', // Cool Blue
  'bg-[#F7941D]', // Bright Orange
  'bg-[#FAD6DC]', // Pastel Pink
  'bg-[#9FE6A0]', // Success Green
  'bg-[#A78BFA]', // Soft Purple
  'bg-[#2B2B2B]', // Dark Gray
];

export const EMOJIS = ['🏃', '💧', '📚', '🧘', '💰', '🍎', '💤', '💻', '🎨', '🎵', '🧹', '💊'];