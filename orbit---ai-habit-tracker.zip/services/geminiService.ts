import { GoogleGenAI } from "@google/genai";
import { Habit, SugarLog } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getMotivationalQuote = async (habitTitle: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Generate a short, punchy, and unique motivational one-liner (max 15 words) specifically for someone trying to build the habit of: "${habitTitle}". Do not use quotes in the output string.`,
    });
    return response.text || "Keep going, you're doing great!";
  } catch (error) {
    console.error("Error fetching motivation:", error);
    return "Consistency is key!";
  }
};

export const getHabitAnalysis = async (habits: Habit[]): Promise<string> => {
  try {
    const habitSummary = habits.map(h => ({
      name: h.title,
      streak: h.streak,
      totalCompletions: h.completedDates.length,
      category: h.category
    }));

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Analyze the following habit data. Be a friendly, constructive coach. 
      Identify patterns, praise high streaks, and offer 1 specific tip for the habit with the lowest consistency.
      Keep the response under 150 words. 
      Data: ${JSON.stringify(habitSummary)}`,
    });
    return response.text || "Great job tracking your habits! Keep it up.";
  } catch (error) {
    console.error("Error analyzing habits:", error);
    return "Unable to analyze habits at the moment. Keep tracking!";
  }
};

export const suggestHabits = async (goal: string): Promise<{ title: string; category: string; icon: string }[]> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `The user wants to achieve this goal: "${goal}". Suggest 3 specific, actionable daily habits to help them. 
      Return ONLY a raw JSON array (no markdown formatting) with objects containing 'title', 'category' (pick from Health, Productivity, Learning, Mindfulness, Fitness, Finance, Other), and 'icon' (a single emoji).`,
      config: {
        responseMimeType: 'application/json'
      }
    });
    
    const text = response.text;
    if (!text) return [];
    return JSON.parse(text);
  } catch (error) {
    console.error("Error suggesting habits:", error);
    return [];
  }
};

export const getSugarAnalysis = async (logs: SugarLog[]): Promise<string> => {
  try {
    // Group by date for better analysis context
    const dailyTotals: Record<string, number> = {};
    logs.forEach(log => {
      dailyTotals[log.date] = (dailyTotals[log.date] || 0) + log.grams;
    });

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Analyze the following daily sugar intake logs (in grams). The World Health Organization recommends keeping free sugars below 25g-50g per day.
      Be a strict but helpful nutritionist. Identify high intake days, trends, and offer specific advice on reducing sugar.
      Keep it under 120 words.
      Data (Daily Totals): ${JSON.stringify(dailyTotals)}`,
    });
    return response.text || "Monitor your sugar intake closely to stay healthy!";
  } catch (error) {
    console.error("Error analyzing sugar:", error);
    return "Unable to analyze sugar data right now.";
  }
};